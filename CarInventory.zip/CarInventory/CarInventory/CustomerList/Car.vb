﻿Option Strict On
Public Class Car


    Private Shared carCount As Integer
    Private carIdentificationNumber As Integer = 0
    Private carMake As String = String.Empty
    Private carModel As String = String.Empty
    Private carPrice As String = String.Empty
    Private carStatus As Boolean = False
    Private carYear As String = String.Empty





    ''' <summary>
    ''' Constructor - Default - creates a new car object
    ''' </summary>
    Public Sub New()

        carCount += 1      ' increment the shared/static variable counter by 1
        carIdentificationNumber = carCount

    End Sub

    ''' <summary>
    ''' Constructor - Parameterized - creates a new car object
    ''' </summary>
    ''' <param name="make"></param>
    ''' <param name="model"></param>
    ''' <param name="price"></param>
    ''' <param name="status"></param>
    ''' <param name="year"></param>
    Public Sub New(make As String, model As String, price As String, status As Boolean, year As String)

        ' call the other constructor 
        ' to set the customer count and
        ' to set the customer id
        Me.New()


        carMake = make
        carModel = model
        carPrice = price
        carStatus = status
        carYear = year


    End Sub


    ''' <summary>
    ''' Count ReadOnly Property - Gets the number of cars that have been instantiated/created
    ''' </summary>
    ''' <returns>Integer</returns>
    Public ReadOnly Property Count() As Integer
        Get
            Return carCount
        End Get
    End Property

    ''' <summary>
    ''' IdentificationNumber ReadOnly Property - Gets a specific cars identification number
    ''' </summary>
    ''' <returns>Integer</returns>
    Public ReadOnly Property IdentificationNumber() As Integer
        Get
            Return carIdentificationNumber
        End Get
    End Property

    ''' <summary>
    ''' Status Property - >Gets and Sets the Very Important status of a car
    ''' </summary>
    ''' <returns>Boolean</returns>
    Public Property Status() As Boolean
        Get
            Return carStatus
        End Get
        Set(ByVal value As Boolean)
            carStatus = value
        End Set
    End Property

    ''' <summary>
    ''' Title property - Gets and Sets the make of a car
    ''' </summary>
    ''' <returns>String</returns>
    Public Property Make() As String
        Get
            Return carMake
        End Get
        Set(ByVal value As String)
            carMake = value
        End Set
    End Property

    ''' <summary>
    ''' FirstName property - Gets and Sets the model of a car
    ''' </summary>
    ''' <returns>String</returns>
    Public Property Model() As String
        Get
            Return carModel
        End Get
        Set(ByVal value As String)
            carModel = value
        End Set
    End Property

    ''' <summary>
    ''' LastName property - Gets and Sets the Year of a car
    ''' </summary>
    ''' <returns>String</returns>
    Public Property Year() As String
        Get
            Return carYear
        End Get
        Set(ByVal value As String)
            carYear = value
        End Set
    End Property
    Public Property Price() As String
        Get
            Return carPrice
        End Get
        Set(ByVal value As String)
            carPrice = value
        End Set
    End Property

    ''' <summary>
    ''' GetSalutation is a function that a salutation based on the private properties within the class scope
    ''' </summary>
    ''' <returns>String</returns>
    Public Function GetSalutation() As String

        Return "My car is " & carMake & " Model is " & carModel & " Price is " & carPrice & " Year is " & carYear & ", " & IIf(carStatus = True, "New One", "Old One").ToString()

    End Function


End Class
